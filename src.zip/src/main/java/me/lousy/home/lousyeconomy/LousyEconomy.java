package me.lousy.home.lousyeconomy;

import org.bukkit.plugin.java.JavaPlugin;

public final class LousyEconomy extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}

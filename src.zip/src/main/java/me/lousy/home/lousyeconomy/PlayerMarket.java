package me.lousy.home.lousyeconomy;

import org.bukkit.inventory.ItemStack;
import java.util.HashMap;
import java.util.Map;

public class PlayerMarket {
    private Map<ItemStack, Double> listedItems;

    public PlayerMarket() {
        this.listedItems = new HashMap<>();
    }

    public void addItemForSale(ItemStack item, double price) {
        listedItems.put(item, price);
    }

    public void removeItemForSale(ItemStack item) {
        listedItems.remove(item);
    }

    public Map<ItemStack, Double> getListedItems() {
        return listedItems;
    }
}


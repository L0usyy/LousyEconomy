package me.lousy.home.lousyeconomy;

// ListCommandExecutor.java
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ListCommandExecutor implements CommandExecutor {
    private PlayerMarket playerMarket;

    public ListCommandExecutor(PlayerMarket playerMarket) {
        this.playerMarket = playerMarket;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("listitem") && sender instanceof Player) {
            Player player = (Player) sender;
            ItemStack itemInHand = player.getInventory().getItemInMainHand();
            double price = Double.parseDouble(args[0]); // Assuming args[0] contains the price
            playerMarket.addItemForSale(itemInHand, price);
            player.sendMessage("Item listed for sale!");
            return true;
        }
        return false;
    }
}
package me.lousy.home.lousyeconomy;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BuyCommandExecutor implements CommandExecutor {
    private PlayerMarket playerMarket;

    public BuyCommandExecutor(PlayerMarket playerMarket) {
        this.playerMarket = playerMarket;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("buyitem") && sender instanceof Player && args.length > 0) {
            Player player = (Player) sender;
            ItemStack item = getItemFromArgs(args[0]); // Implement a method to get item from args
            double price = playerMarket.getListedItems().get(item);
            if (price > 0 && playerHasEnoughMoney(player, price)) {
                // Remove money from player (Implement your economy system)
                // Give item to player
                player.sendMessage("Item purchased!");
            } else {
                player.sendMessage("Insufficient funds or invalid item!");
            }
            return true;
        }
        return false;
    }

    private boolean playerHasEnoughMoney(Player player, double amount) {
        // Implement a method to check if player has enough money
        return true; // Return true if player has enough money, false otherwise
    }

    private ItemStack getItemFromArgs(String arg) {
        // Implement a method to get item from argument string
        // You can use Bukkit's Material enum and ItemStack's constructor
        return new ItemStack(Material.STONE); // Placeholder item, replace with actual logic
    }
}